﻿namespace server.Main.Users.CharacterClasses
{


    public class CharacterMoney
    {
        public int Cash;
        public int Bank;
        public int UnTaxed;

    }
}
